package com.betterfly.app.ui.stats

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.foundation.Canvas
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import java.text.SimpleDateFormat
import java.util.*

@Composable
internal fun TrendSparkline(values: List<Long>, color: Color) {
    val max = (values.maxOrNull() ?: 1L).toFloat().coerceAtLeast(1f)
    val min = (values.minOrNull() ?: 0L).toFloat()
    Card(colors = CardDefaults.cardColors(color.copy(alpha = 0.07f)), shape = RoundedCornerShape(10.dp)) {
        Canvas(Modifier.fillMaxWidth().height(72.dp).padding(8.dp)) {
            if (values.size < 2) return@Canvas
            val path = Path(); val w = size.width; val h = size.height
            values.forEachIndexed { i, v ->
                val x = i.toFloat() / (values.size - 1) * w
                val y = h - ((v - min) / (max - min + 0.001f)) * h
                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            drawPath(path, color = color, style = Stroke(width = 2.5f))
        }
    }
}

@Composable
internal fun HourSpectrum(map: Map<Int, Long>, color: Color) {
    val max = (map.values.maxOrNull() ?: 1L).toFloat().coerceAtLeast(1f)
    Column {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
            for (h in 0..23) {
                val v = map[h]?.toFloat() ?: 0f
                val alpha = if (v > 0) (v / max).coerceIn(0.12f, 1f) else 0.06f
                Box(Modifier.weight(1f).height(22.dp).clip(RoundedCornerShape(3.dp)).background(color.copy(alpha = alpha)))
            }
        }
        Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) {
            listOf("0", "6", "12", "18", "24").forEach {
                Text(it, style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f))
            }
        }
    }
}

@Composable
internal fun Heatmap12Weeks(data: Map<String, Int>, color: Color) {
    val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
    val cal = Calendar.getInstance()
    cal.add(Calendar.DAY_OF_YEAR, -83)
    val days = mutableListOf<String>()
    repeat(84) { days.add(sdf.format(cal.time)); cal.add(Calendar.DAY_OF_YEAR, 1) }
    val maxVal = (data.values.maxOrNull() ?: 1).coerceAtLeast(1)
    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
        for (row in 0 until 7) {
            Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                for (col in 0 until 12) {
                    val value = days.getOrNull(col * 7 + row)?.let { data[it] } ?: 0
                    val alpha = if (value <= 0) 0.07f else (value.toFloat() / maxVal).coerceIn(0.2f, 1f)
                    Box(Modifier.size(13.dp).clip(RoundedCornerShape(2.dp)).background(color.copy(alpha = alpha)))
                }
            }
        }
    }
}
