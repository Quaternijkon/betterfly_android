package com.betterfly.app.ui.home

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.betterfly.app.data.Session
import com.betterfly.app.util.parseHexColor

@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun NoteStopDialog(onDismiss: () -> Unit, onSave: (String?) -> Unit) {
    var note by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("结束记录") },
        text = {
            OutlinedTextField(
                value = note,
                onValueChange = { note = it },
                label = { Text("备注（可选）") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = false,
                minLines = 2
            )
        },
        confirmButton = { TextButton({ onSave(note.ifBlank { null }) }) { Text("保存") } },
        dismissButton = { TextButton(onDismiss) { Text("取消") } }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun InteractiveStopDialog(
    session: Session,
    onDismiss: () -> Unit,
    onQuickStop: () -> Unit,
    onSave: (String?, Int?, Boolean) -> Unit
) {
    var note by remember { mutableStateOf("") }
    var rating by remember { mutableStateOf(0) }
    var incomplete by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("结束记录", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = note,
                    onValueChange = { note = it },
                    label = { Text("备注（可选）") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = false,
                    minLines = 2
                )
                Text("力竭程度 (1-5)", style = MaterialTheme.typography.labelMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    val labels = listOf("轻松", "有点", "吃力", "接近", "力竭")
                    labels.forEachIndexed { idx, label ->
                        val level = idx + 1
                        val selected = rating == level
                        FilterChip(
                            selected = selected,
                            onClick = { rating = if (selected) 0 else level },
                            label = { Text("$level $label", style = MaterialTheme.typography.labelSmall) }
                        )
                    }
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("标记未完成", style = MaterialTheme.typography.bodyMedium)
                    Switch(checked = incomplete, onCheckedChange = { incomplete = it })
                }
            }
        },
        confirmButton = {
            Button(onClick = { onSave(note.ifBlank { null }, rating.takeIf { it in 1..5 }, incomplete) }) {
                Text("保存")
            }
        },
        dismissButton = { TextButton(onQuickStop) { Text("快速停止") } }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun CreateEventDialog(onDismiss: () -> Unit, onConfirm: (String, String, List<String>) -> Unit) {
    var name by remember { mutableStateOf("") }
    var selectedColor by remember { mutableStateOf(PRESET_COLORS.first()) }
    var tagsText by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("新建事件", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("事件名称") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                Text("主题色", style = MaterialTheme.typography.labelMedium)
                ColorPicker(selectedColor = selectedColor, onColorSelected = { selectedColor = it })
                OutlinedTextField(
                    value = tagsText,
                    onValueChange = { tagsText = it },
                    label = { Text("标签（逗号分隔，可选）") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val tags = tagsText.split(",").map { it.trim() }.filter { it.isNotBlank() }
                    onConfirm(name.trim(), selectedColor, tags)
                },
                enabled = name.isNotBlank()
            ) { Text("创建") }
        },
        dismissButton = { TextButton(onDismiss) { Text("取消") } }
    )
}

@Composable
internal fun ColorPicker(selectedColor: String, onColorSelected: (String) -> Unit) {
    val rows = PRESET_COLORS.chunked(6)
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        rows.forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                row.forEach { hex ->
                    val c = parseHexColor(hex)
                    val selected = hex.equals(selectedColor, ignoreCase = true)
                    Box(
                        modifier = Modifier
                            .size(if (selected) 30.dp else 26.dp)
                            .clip(CircleShape)
                            .background(c)
                            .clickable { onColorSelected(hex) },
                        contentAlignment = Alignment.Center
                    ) {
                        if (selected) {
                            Icon(
                                Icons.Default.Check, null,
                                modifier = Modifier.size(14.dp),
                                tint = androidx.compose.ui.graphics.Color.White
                            )
                        }
                    }
                }
            }
        }
    }
}
