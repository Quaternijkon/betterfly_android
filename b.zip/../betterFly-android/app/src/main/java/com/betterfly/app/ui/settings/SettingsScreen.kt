package com.betterfly.app.ui.settings

import android.app.Activity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.betterfly.app.util.parseHexColor
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import com.google.firebase.auth.GoogleAuthProvider

private val THEME_COLORS = listOf(
    "#4285F4", "#EA4335", "#FBBC05", "#34A853",
    "#8b5cf6", "#ec4899", "#6366f1", "#14b8a6"
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    onNavigateBack: () -> Unit,
    viewModel: SettingsViewModel = hiltViewModel()
) {
    val settings by viewModel.settings.collectAsState()
    val msg by viewModel.message.collectAsState()
    val clipboard = LocalClipboardManager.current
    val context = LocalContext.current
    var showAuthDialog by remember { mutableStateOf(false) }
    var showImportDialog by remember { mutableStateOf(false) }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var importJson by remember { mutableStateOf("") }

    val googleLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val task = GoogleSignIn.getSignedInAccountFromIntent(result.data)
            try {
                val account = task.getResult(ApiException::class.java)
                val credential = GoogleAuthProvider.getCredential(account.idToken, null)
                viewModel.signInWithGoogleCredential(credential)
            } catch (e: Exception) {
                viewModel.setMessage("Google 登录失败: ${e.message}")
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("设置", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) { Icon(Icons.Default.ArrowBack, "返回") }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { padding ->
        LazyColumn(
            contentPadding = PaddingValues(
                start = 16.dp, end = 16.dp,
                top = padding.calculateTopPadding() + 8.dp,
                bottom = 100.dp
            ),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                SettingsCard(title = "外观") {
                    SettingsRow(label = "深色模式") {
                        Switch(checked = settings.darkMode, onCheckedChange = { viewModel.updateDarkMode(it) })
                    }
                    Spacer(Modifier.height(8.dp))
                    Text("主题色", style = MaterialTheme.typography.bodyMedium)
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        THEME_COLORS.forEach { hex ->
                            val c = parseHexColor(hex)
                            val selected = settings.themeColor.equals(hex, ignoreCase = true)
                            Box(
                                modifier = Modifier.size(if (selected) 32.dp else 26.dp)
                                    .clip(CircleShape).background(c)
                                    .clickable { viewModel.updateThemeColor(hex) },
                                contentAlignment = Alignment.Center
                            ) {
                                if (selected) Icon(Icons.Default.Check, null, Modifier.size(14.dp),
                                    tint = androidx.compose.ui.graphics.Color.White)
                            }
                        }
                    }
                }
            }
            item {
                SettingsCard(title = "偏好") {
                    SettingsRow(label = "周起始日") {
                        Row {
                            TextButton({ viewModel.updateWeekStart(1) }) {
                                Text(if (settings.weekStart == 1) "周一 ✓" else "周一")
                            }
                            TextButton({ viewModel.updateWeekStart(0) }) {
                                Text(if (settings.weekStart == 0) "周日 ✓" else "周日")
                            }
                        }
                    }
                    SettingsRow(label = "停止方式") {
                        Row {
                            TextButton({ viewModel.updateStopMode("quick") }) {
                                Text(if (settings.stopMode == "quick") "快速 ✓" else "快速")
                            }
                            TextButton({ viewModel.updateStopMode("note") }) {
                                Text(if (settings.stopMode == "note") "备注 ✓" else "备注")
                            }
                            TextButton({ viewModel.updateStopMode("interactive") }) {
                                Text(if (settings.stopMode == "interactive") "详细 ✓" else "详细")
                            }
                        }
                    }
                }
            }
            item {
                SettingsCard(title = "账号与同步") {
                    SettingsButton("邮箱登录 / 注册") { showAuthDialog = true }
                    SettingsButton("游客登录") { viewModel.signInAnonymously() }
                    SettingsButton("Google 登录") {
                        val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                            .requestIdToken(context.getString(com.betterfly.app.R.string.default_web_client_id))
                            .requestEmail().build()
                        googleLauncher.launch(GoogleSignIn.getClient(context, gso).signInIntent)
                    }
                    SettingsButton("GitHub 登录") { viewModel.signInWithGithub() }
                    SettingsButton("Microsoft 登录") { viewModel.signInWithMicrosoft() }
                    HorizontalDivider(Modifier.padding(vertical = 4.dp))
                    SettingsButton("立即双向同步") { viewModel.syncNow() }
                    SettingsButton("用本地覆盖云端") { viewModel.overwriteCloud() }
                    SettingsButton("去重会话") { viewModel.deduplicate() }
                    SettingsButton("清空本地数据", isDestructive = true) { viewModel.clearLocalData() }
                    SettingsButton("退出登录", isDestructive = true) { viewModel.signOut() }
                }
            }
            item {
                SettingsCard(title = "导入 / 导出") {
                    Text("支持 JSON 格式备份，导入会覆盖本地数据。",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(6.dp))
                    SettingsButton("导出 JSON 到剪贴板") {
                        viewModel.exportBackupJson { json -> clipboard.setText(AnnotatedString(json)) }
                    }
                    SettingsButton("从 JSON 导入") { showImportDialog = true; importJson = "" }
                }
            }
        }
    }

    if (showAuthDialog) {
        AlertDialog(
            onDismissRequest = { showAuthDialog = false },
            title = { Text("邮箱登录 / 注册") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(email, { email = it }, Modifier.fillMaxWidth(), label = { Text("邮箱") }, singleLine = true)
                    OutlinedTextField(password, { password = it }, Modifier.fillMaxWidth(), label = { Text("密码") }, singleLine = true, visualTransformation = PasswordVisualTransformation())
                }
            },
            confirmButton = {
                TextButton(onClick = { viewModel.signInWithEmailOrRegister(email.trim(), password); showAuthDialog = false }) { Text("继续") }
            },
            dismissButton = { TextButton({ showAuthDialog = false }) { Text("取消") } }
        )
    }

    if (showImportDialog) {
        AlertDialog(
            onDismissRequest = { showImportDialog = false },
            title = { Text("从 JSON 导入") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("会覆盖当前本地数据，请先确认已备份。", style = MaterialTheme.typography.bodySmall)
                    OutlinedTextField(importJson, { importJson = it }, Modifier.fillMaxWidth(), label = { Text("粘贴 JSON") }, minLines = 4)
                }
            },
            confirmButton = {
                TextButton(onClick = { viewModel.importBackupJson(importJson); showImportDialog = false }) { Text("导入") }
            },
            dismissButton = { TextButton({ showImportDialog = false }) { Text("取消") } }
        )
    }

    if (!msg.isNullOrBlank()) {
        LaunchedEffect(msg) { kotlinx.coroutines.delay(2500); viewModel.clearMessage() }
        AlertDialog(
            onDismissRequest = { viewModel.clearMessage() },
            title = { Text("提示") }, text = { Text(msg ?: "") },
            confirmButton = { TextButton({ viewModel.clearMessage() }) { Text("知道了") } }
        )
    }
}
